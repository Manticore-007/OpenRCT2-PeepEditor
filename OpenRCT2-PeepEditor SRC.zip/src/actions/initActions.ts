import { GuestConditionArgs, guestConditionExecute } from "./guestCondition";
import { GuestFlagsArgs, guestFlagsExecute } from "./guestFlags";
import { GuestItemRemoveArgs, guestItemRemoveExecute } from "./guestItemRemove";
import { PeepAnimationArgs, animationPeepExecute } from "./peepAnimation";
import { PeepAnimationFrameArgs, animationFramePeepExecute } from "./peepAnimationFrame";
import { PeepColourArgs, colourPeepExecute } from "./peepColour";
import { PeepMoveArgs, movePeepExecute } from "./peepMover";
import { PeepNameArgs, namePeepExecute } from "./peepNamer";
import { PeepRemoveArgs, removePeepExecute } from "./peepRemover";
import { peepRotateExecute } from "./peepRotater";
import { queryPermissionCheck } from "./permissions";
import { StaffCostumeArgs, staffCostumeExecute } from "./staffSetCostume";
import { StaffOrdersArgs, staffOrdersExecute } from "./staffSetOrders";
import { StaffTypeArgs, staffTypeExecute } from "./staffSetType";

export function initActions(): void
{
context.registerAction<PeepNameArgs>("pe-namepeep", (args) => queryPermissionCheck(args), (args) => namePeepExecute(args.args));
context.registerAction<PeepRemoveArgs>("pe-removepeep", (args) => queryPermissionCheck(args), (args) => removePeepExecute(args.args));
context.registerAction<PeepMoveArgs>("pe-movepeep", (args) => queryPermissionCheck(args), (args) => movePeepExecute(args.args));
context.registerAction<PeepColourArgs>("pe-colourpeep", (args) => queryPermissionCheck(args), (args) => colourPeepExecute(args.args));
context.registerAction<StaffTypeArgs>("pe-stafftype", (args) => queryPermissionCheck(args), (args) => staffTypeExecute(args.args));
context.registerAction<StaffOrdersArgs>("pe-stafforders", (args) => queryPermissionCheck(args), (args) => staffOrdersExecute(args.args));
context.registerAction<StaffCostumeArgs>("pe-staffcostume", (args) => queryPermissionCheck(args), (args) => staffCostumeExecute(args.args));
context.registerAction<PeepAnimationArgs>("pe-animationpeep", (args) => queryPermissionCheck(args), (args) => animationPeepExecute(args.args));
context.registerAction<PeepAnimationFrameArgs>("pe-animationframepeep", (args) => queryPermissionCheck(args), (args) => animationFramePeepExecute(args.args));
context.registerAction<GuestFlagsArgs>("pe-guestflags", (args) => queryPermissionCheck(args), (args) => guestFlagsExecute(args.args));
context.registerAction<GuestConditionArgs>("pe-guestcondition", (args) => queryPermissionCheck(args), (args) => guestConditionExecute(args.args));
context.registerAction<GuestItemRemoveArgs>("pe-guestitemremove", (args) => queryPermissionCheck(args), (args) => guestItemRemoveExecute(args.args));
context.registerAction("pe-peeprotate", (args) => queryPermissionCheck(args), () => peepRotateExecute());
}